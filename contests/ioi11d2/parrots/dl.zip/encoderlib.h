void send(int a);
