int besthub(int R, int L, int X[], long long B);
