void count_routes(int N, int M, int P, int R[][2], int Q, int G[]);
