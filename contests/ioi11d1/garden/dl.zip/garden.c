#include "garden.h"
#include "gardenlib.h"

void count_routes(int N, int M, int P, int R[][2], int Q, int G[])
{
  int i;

  for(i=0; i<Q; i++)
    answer(N);
}


