#include "friend.h"

// Find out best sample
int findSample(int n,int confidence[],int host[],int protocol[]){
	int ans=10;
	return ans;
}
