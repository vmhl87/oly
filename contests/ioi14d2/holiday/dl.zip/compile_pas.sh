#!/bin/bash

NAME=holiday

/usr/bin/fpc -XS -O2 -o$NAME grader.pas
