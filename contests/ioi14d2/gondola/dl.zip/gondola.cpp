#include "gondola.h"

int valid(int n, int inputSeq[])
{
  return -1;
}

//----------------------

int replacement(int n, int gondolaSeq[], int replacementSeq[])
{
  return -2;
}

//----------------------

int countReplacement(int n, int inputSeq[])
{
  return -3;
}
