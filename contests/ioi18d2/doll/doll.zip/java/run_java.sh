java -Xmx1024M -Xss1024M -cp doll.jar grader
