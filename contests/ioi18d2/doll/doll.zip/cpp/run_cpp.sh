#!/bin/bash

TASK=doll

./${TASK}
