#!/bin/bash

TASK=meetings

./${TASK}
