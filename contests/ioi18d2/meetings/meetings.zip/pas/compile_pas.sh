#!/bin/bash

TASK=meetings

fpc -XS -O2 -o${TASK} grader.pas
