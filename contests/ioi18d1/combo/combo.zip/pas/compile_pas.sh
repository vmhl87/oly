#!/bin/bash

TASK=combo

fpc -XS -O2 -o${TASK} grader.pas
