#!/bin/bash

TASK=werewolf

./${TASK}
